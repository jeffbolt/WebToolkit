﻿Imports Bolt.Math

Module Main
    Sub Main()
        Console.Clear()
        'Dim intNumber As Integer = 379

        'If IsPrime(intNumber) Then
        '    Console.WriteLine(intNumber.ToString & " is a prime number.")
        'Else
        '    Console.WriteLine(intNumber.ToString & " is not a prime number.")
        'End If

        'If IsHappy(intNumber) Then
        '    Console.WriteLine(intNumber.ToString & " is a happy number.")
        'Else
        '    Console.WriteLine(intNumber.ToString & "is not a happy number.")
        'End If

        'intNumber = 101
        'If IsPalindromic(intNumber) Then
        '    Console.WriteLine(intNumber.ToString & " is a palindromic number.")
        'Else
        '    Console.WriteLine(intNumber.ToString & " is not a palindromic number.")
        'End If

        For i As Integer = 1 To 1000
            If IsPrime(i) Then
                Console.WriteLine(i & " is a prime number.")
                If IsHappy(i) Then
                    Console.WriteLine(i & " is a happy prime number.")
                    If IsPalindromic(i) Then
                        Console.WriteLine(i & " is a palindromic prime number.")
                    Else
                        'Console.WriteLine(i & " is NOT a palindromic prime number.")
                    End If
                'Else
                    'Console.WriteLine(i & " is NOT a happy prime number.")
                End If
                'Else
                '    Console.WriteLine(i & " is NOT prime number.")
                '    If IsHappy(i) Then
                '        Console.WriteLine(i & " is a happy number.")
                '    Else
                '        Console.WriteLine(i & " is not a happy number.")
                '    End If

                '    If IsPalindromic(i) Then
                '        Console.WriteLine(i & " is palindromic number.")
                '    Else
                '        Console.WriteLine(i & " is NOT palindromic number.")
                '    End If
            End If


        Next

        Console.WriteLine("Press any key to exit.")
        Console.ReadKey()
        'Dim cki As ConsoleKeyInfo = Console.ReadKey

        'While cki.Key <> ConsoleKey.Q
        '    cki = Console.ReadKey
        'End While
    End Sub
End Module
