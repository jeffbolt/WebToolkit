﻿Public Class Math
    Private Sub New()
    End Sub

    Public Shared Function IsHappy(ByVal Number As Integer, Optional PrevNumbers As String = "") As Boolean
        'Happy Numbers: https://en.wikipedia.org/wiki/Happy_number
        'Happy Primes: https://oeis.org/A035497
        Dim arrDigits As Char() = Number.ToString.ToCharArray
        Dim intSum As Integer

        For Each c As Char In arrDigits
            intSum += System.Math.Pow(CInt(c.ToString), 2)
        Next

        Debug.Write(intSum)

        If intSum = 1 Then
            Return True
        Else
            'Not happy if its sequence ends in the cycle {4, 16, 37, 58, 89, 145, 42, 20, 4}
            Select Case intSum
                Case 4, 16, 37, 58, 89, 145, 42, 20
                    PrevNumbers += intSum.ToString & ","
            End Select

            If Right(PrevNumbers, 26) = "4,16,37,58,89,145,42,20,4," Then
                Return False
            End If

            'Debug.Indent()
            Debug.Write(", ")
            Dim intNew As Integer = CInt(intSum.ToString)
            Return IsHappy(intNew, PrevNumbers)
        End If
    End Function

    Public Shared Function IsPrime(ByVal Number As Integer) As Boolean
        'https://en.wikipedia.org/wiki/Prime_number
        For i As Integer = 2 To Number - 1
            If Number Mod i = 0 Then Return False
        Next

        Return True
    End Function

    Public Shared Function IsPalindromic(ByVal Number As Integer) As Boolean
        'https://en.wikipedia.org/wiki/Palindromic_number
        Return Number.ToString = StrReverse(Number.ToString)
    End Function
End Class
